package demoBilhete;

import static org.junit.Assert.*;

import org.junit.Test;

public class MeusTestes {

	@Test
		public void testObterPreco_11anos(){
			System.out.println("obterPreco11anos");
			Bilhete bilhete=new Bilhete(8.0);
			int idade=11;
			Double resultadoEsperado=5.0;
			
			Double resultado=bilhete.obterPreco(idade);
			assertEquals(resultadoEsperado,resultado);
		}
	
	@Test
	public void testObterPreco_12anos(){
		System.out.println("obterPreco12");
		Bilhete bilhete=new Bilhete(8.0);
		int idade=12;
		Double resultadoEsperado2=8.0;
		
		Double resultado2=bilhete.obterPreco(idade);
		assertEquals(resultadoEsperado2,resultado2);
	}
	
	@Test
	public void testObterPreco_71anos(){
		System.out.println("obterPreco71anos");
		Bilhete bilhete=new Bilhete(8.0);
		int idade=71;
		Double resultadoEsperado2=4.0;
		
		Double resultado2=bilhete.obterPreco(idade);
		assertEquals(resultadoEsperado2,resultado2);
	}
	
	@Test
	public void testObterPreco_70anos(){
		System.out.println("obterPreco70anos");
		Bilhete bilhete=new Bilhete(8.0);
		int idade=70;
		Double resultadoEsperado2=8.0;
		
		Double resultado2=bilhete.obterPreco(idade);
		assertEquals(resultadoEsperado2,resultado2);
	}
	
	
	@Test
	public void testObterPreco_20anos(){
		System.out.println("obterPreco20anos");
		Bilhete bilhete=new Bilhete(8.0);
		int idade=20;
		Double resultadoEsperado3=8.0;
		
		Double resultado3=bilhete.obterPreco(idade);
		assertEquals(resultadoEsperado3,resultado3);
	}
}
