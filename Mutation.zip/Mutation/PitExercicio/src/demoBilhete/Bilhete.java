package demoBilhete;

public class Bilhete {
	
	private final double precoBilhete;
	
	public Bilhete(double precoBilhete){
		this.precoBilhete=precoBilhete;
	}
	
	public double obterPreco(int idade){
		if (idade<12 ){
			return 5.0;
		}
		if (idade>70){
			return precoBilhete/2;
		}
		return precoBilhete;
	}
	
}
