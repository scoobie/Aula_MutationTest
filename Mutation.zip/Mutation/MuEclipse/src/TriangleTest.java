import junit.framework.TestCase;

public class TriangleTest extends TestCase {
	
	Triangle tri=new Triangle();
	
	//INVALID
	public void testT0(){
		assertEquals(0,tri.Type_Area(2, 2, 5));
	}
	
	//EQUILATERAL
	public void testT1(){
		assertEquals(3,tri.Type_Area(2, 2, 2));
	}
	
	//ISOCELES
	public void testT2(){
		assertEquals(2,tri.Type_Area(4, 4, 3));
	}
	
	//SCALENE
	public void testT3(){
		assertEquals(1,tri.Type_Area(5, 4, 3));
	}

	//SCALENE
	public void testT4(){
		assertEquals(1,tri.Type_Area(6, 5, 4));
	}
	
	//EQUILATERAL
	public void testT5(){
		assertEquals(3,tri.Type_Area(3, 3, 3));
	}
	
	//ISOCELES
	public void testT6(){
		assertEquals(2,tri.Type_Area(4, 3, 3));
	}

}
